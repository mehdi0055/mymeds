<?php return array (
  'about-component' => 'App\\Http\\Livewire\\AboutComponent',
  'admin.admin-dashboard-component' => 'App\\Http\\Livewire\\Admin\\AdminDashboardComponent',
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'user.user-dashboard-component' => 'App\\Http\\Livewire\\User\\UserDashboardComponent',
);