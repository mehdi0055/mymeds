


<?php /**PATH C:\xampp\htdocs\mymeds\resources\views/layouts/app.blade.php ENDPATH**/ ?>