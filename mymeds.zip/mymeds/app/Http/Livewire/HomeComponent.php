<?php

namespace App\Http\Livewire;

use Livewire\Component;

class HomeComponent extends Component
{
    public function render()
    {
        $title = __('language.home');
        return view('livewire.home-component')->layout('layouts.landing',compact('title'));
    }
}
