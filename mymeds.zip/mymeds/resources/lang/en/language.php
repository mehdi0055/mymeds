<?php


    return [
        'home' => 'Home',
        'about' =>'About us',
        'contact' => 'Contact us',
        'profile' => 'My profile',
        'messages' => 'Messages',
        'settings' => 'Settings',
        'welcome' => 'Welcome',
        'title'=> 'Management software for your medical practice', 
        'dashboard' => 'Dashboard',
        'login' => 'Login/Register',
        'logout' => 'Logout',
    ];


?>