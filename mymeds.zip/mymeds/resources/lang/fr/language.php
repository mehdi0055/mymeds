<?php


    return [
        'home' => 'Accueil',
        'about' =>'À propos de nous',
        'contact' => 'Contactez-nous',
        'profile' => 'Mon profil',
        'messages' => 'Messages',
        'settings' => 'Réglages',
        'welcome' => 'Bienvenu',
        'title' => 'Logiciel de gestion de votre cabinet médical',
        'dashboard' => 'Tableau de bord',
        'login' => 'Connexion/S\'inscrire',
        'logout' => 'Déconnecter',
    ];


?>